import { Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const Chat = () => {
    return (
        <SafeAreaView>
            <Text>Chat</Text>
        </SafeAreaView>
    );
};

export default Chat;
