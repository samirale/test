import { Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const Rides = () => {
    return (
        <SafeAreaView>
            <Text>Rides</Text>
        </SafeAreaView>
    );
};

export default Rides;
